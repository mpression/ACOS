//
//  HitogataMainViewController.m
//  HitogataApp
//
//

#import "HitogataMainViewController.h"
#import "Konashi.h"

@interface HitogataMainViewController ()

@end

@implementation HitogataMainViewController

int inputSensor;
int ledColor;
int condition;
float cycle;
float threshold;
bool isDemo;

GKPeerPickerController *gkPicker;
GKSession *currentSession;
NSString *gkPeerID;
NSTimer *ledTimer;
NSTimer *checkSensorTimer;
int checkSensorStep;

bool LED_R_ENABLE;
bool LED_G_ENABLE;
bool LED_B_ENABLE;
bool isReact;
bool isLieOnBack;
bool isLieOnSide;
bool isShake;
NSDate *actionStartTime;

bool waitI2CResp;

- (void)viewDidLoad
{
    [super viewDidLoad];
	[Konashi initialize];
    //[self initSetting];
    //[self loadSetting];
    isDemo = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    //_parameterDisplay.center = CGPointMake(160, 700);
    [self resetParameterDisplay];
    [self setInputSensor:inputSensor];
    [self setThreshold:threshold];
    _settingButton.hidden = YES;
}

- (void)initSetting
{
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSMutableDictionary *md = [NSMutableDictionary dictionary];
    
    NSArray *initialThresholds = [NSArray arrayWithObjects:
                                  [NSNumber numberWithFloat:0.0],
                                  [NSNumber numberWithFloat:2.0],
                                  [NSNumber numberWithFloat:30.0],
                                  [NSNumber numberWithFloat:0.5],
                                  [NSNumber numberWithFloat:0.5],
                                  [NSNumber numberWithFloat:0.5],
                                  nil];
    
    NSArray *initialConditions = [NSArray arrayWithObjects:
                                  [NSNumber numberWithInt:-1],
                                  [NSNumber numberWithInt:0],
                                  [NSNumber numberWithInt:0],
                                  [NSNumber numberWithInt:0],
                                  [NSNumber numberWithInt:0],
                                  [NSNumber numberWithInt:0],
                                  nil];
    
    NSArray *initialCycles = [NSArray arrayWithObjects:
                              [NSNumber numberWithFloat:0.0],
                              [NSNumber numberWithFloat:1.0],
                              [NSNumber numberWithFloat:1.0],
                              [NSNumber numberWithFloat:1.0],
                              [NSNumber numberWithFloat:1.0],
                              [NSNumber numberWithFloat:1.0],
                              nil];
    
    NSArray *initialLedColors = [NSArray arrayWithObjects:
                                 [NSNumber numberWithInt:-1],
                                 [NSNumber numberWithInt:0],
                                 [NSNumber numberWithInt:0],
                                 [NSNumber numberWithInt:0],
                                 [NSNumber numberWithInt:0],
                                 [NSNumber numberWithInt:0],
                                 nil];
    
    NSNumber *initialInputSensor = [NSNumber numberWithInt:ACCELERATION_SENSOR];
    
    [md setObject:initialThresholds forKey:@"thresholds"];
    [md setObject:initialConditions forKey:@"conditions"];
    [md setObject:initialCycles forKey:@"cycles"];
    [md setObject:initialLedColors forKey:@"ledColors"];
    [md setObject:initialInputSensor forKey:@"inputSensor"];
    
    [ud registerDefaults:md];
    
}

- (void)loadSetting
{
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    
    NSMutableArray *thresholds = [[ud arrayForKey:@"thresholds"] mutableCopy];
    NSMutableArray *conditions = [[ud arrayForKey:@"conditions"] mutableCopy];
    NSMutableArray *cycles     = [[ud arrayForKey:@"cycles"] mutableCopy];
    NSMutableArray *ledColors  = [[ud arrayForKey:@"ledColors"] mutableCopy];
    
    inputSensor = (int)[ud integerForKey:@"inputSensor"];
    threshold   = [[thresholds objectAtIndex:inputSensor] floatValue];
    condition   = (int)[[conditions objectAtIndex:inputSensor] integerValue];
    cycle       = [[cycles objectAtIndex:inputSensor] floatValue];
    ledColor    = (int)[[ledColors objectAtIndex:inputSensor] integerValue];
}




#pragma mark - Flipside View

- (void)flipsideViewControllerDidFinish:(HitogataFlipsideViewController *)controller
{
    [self dismissViewControllerAnimated:YES completion:nil];
    if([Konashi isConnected]) [self startCheckSensor];
    
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([Konashi isConnected]) [self stopCheckSensor];
    if ([[segue identifier] isEqualToString:@"showAlternate"]) {
        [[segue destinationViewController] setDelegate:self];
    }
}




#pragma mark -
#pragma mark - Konashi-iPhone Pairing

- (IBAction)tapDevicePairing:(id)sender
{
    if(![Konashi isConnected])
    {
        [Konashi addObserver:self selector:@selector(konashiNotFound) name:KONASHI_EVENT_KONASHI_NOT_FOUND];
        [Konashi addObserver:self selector:@selector(konashiIsReady) name:KONASHI_EVENT_READY];
        [Konashi addObserver:self selector:@selector(konashiFindCanceled) name:KONASHI_EVENT_CANCEL_KONASHI_FIND];
        [Konashi find];
    }
    else
    {
        [Konashi addObserver:self selector:@selector(konashiIsDisconnected) name:KONASHI_EVENT_DISCONNECTED];
        [Konashi disconnect];
    }
}

- (void)konashiNotFound
{
    [Konashi removeObserver:self];
}

- (void)konashiFindCanceled
{
    [Konashi removeObserver:self];
}

- (void)konashiIsDisconnected
{
    [Konashi removeObserver:self];
    
    [_devicePairingButton setTitle:@"connect" forState:UIControlStateNormal];
    [[_devicePairingButton layer] setBackgroundColor:[[UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:1.0] CGColor]];
    [_sensorCondition setBackgroundColor:[UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:1.0]];
    
    [self stopCheckSensor];
}

- (void)konashiIsReady
{
    [Konashi removeObserver:self];
    
    [_devicePairingButton setTitle:@"disconnect" forState:UIControlStateNormal];
    [[_devicePairingButton layer] setBackgroundColor:[[UIColor colorWithRed:0.0 green:0.6 blue:0.0 alpha:1.0] CGColor]];
    
    //Konash I/O setting
    [Konashi pinModeAll:0b00001110];
    [Konashi i2cMode:KONASHI_I2C_ENABLE];
    
    //flash device's LED
    [Konashi digitalWrite:PIO0 value:HIGH];
    [NSThread sleepForTimeInterval:0.2];
    [Konashi digitalWrite:PIO0 value:LOW];
    [Konashi digitalWrite:PIO1 value:HIGH];
    [NSThread sleepForTimeInterval:0.2];
    [Konashi digitalWrite:PIO1 value:LOW];
    [Konashi digitalWrite:PIO2 value:HIGH];
    [NSThread sleepForTimeInterval:0.2];
    [Konashi digitalWrite:PIO2 value:LOW];
    
    [self startCheckSensor];
}





#pragma mark - Konashi Input Control

- (void)startCheckSensor
{
    NSLog(@"Start check sensor.");
    
    isLieOnBack = NO;
    isLieOnSide = NO;
    isShake = NO;
    isReact = NO;
    waitI2CResp = NO;
    checkSensorStep = 0;
    
    if(!isDemo) inputSensor = ACCELERATION_SENSOR;
    
    switch(inputSensor)
    {
        case ACCELERATION_SENSOR:
        {
            //initialize
            //Sensor Event Handller
            [Konashi addObserver:self selector:@selector(who_am_i) name:KONASHI_EVENT_I2C_READ_COMPLETE];
            unsigned char data[2];
            
            [Konashi i2cStartCondition];
            [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
            
            // Enable Sensor Axis
            data[0] = 0x20;
            //data[1] = 0x7F;
            data[1] = 0x3F;
            [Konashi i2cWrite:2 data:data address:ACCELERATION_SENSOR_ADDRESS];
            [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
            [Konashi i2cStopCondition];
            [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
            
            // Who am I?
            data[0] = 0x0F;
            [Konashi i2cStartCondition];
            [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
            [Konashi i2cWrite:1 data:data address:ACCELERATION_SENSOR_ADDRESS];
            [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
            [Konashi i2cRestartCondition];
            [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
            [Konashi i2cReadRequest:1 address:ACCELERATION_SENSOR_ADDRESS];
            [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
            break;
        }
            
        case TEMPERATURE_SENSOR:
        {
            //initialize
            //Sensor Event Handller
            [Konashi addObserver:self selector:@selector(updateI2C48) name:KONASHI_EVENT_I2C_READ_COMPLETE];
            unsigned char data[2];
            data[0]=0x00;
            [Konashi i2cStartCondition];
            [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
            [Konashi i2cWrite:1 data:data address:TEMPERATURE_SENSOR_ADDRESS];
            [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
            [Konashi i2cRestartCondition];
            [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
            [Konashi i2cReadRequest:2 address:TEMPERATURE_SENSOR_ADDRESS];
            [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
            break;
        }
        case ILLUMINANCE_SENSOR:
            [Konashi addObserver:self selector:@selector(updateAio0) name:KONASHI_EVENT_UPDATE_ANALOG_VALUE_AIO0];
            break;
            
        case PRESSURE_SENSOR:
            [Konashi addObserver:self selector:@selector(updateAio1) name:KONASHI_EVENT_UPDATE_ANALOG_VALUE_AIO1];
            break;
            
        case VOLUME_SENSOR:
            [Konashi addObserver:self selector:@selector(updateAio2) name:KONASHI_EVENT_UPDATE_ANALOG_VALUE_AIO2];
            break;
    }
    
    //[self showParameterDisplay];
    
    if(isDemo)
    {
        checkSensorTimer = [NSTimer scheduledTimerWithTimeInterval:CHECK_SENSOR_INTERVAL
                                                            target:self
                                                          selector:@selector(checkSensor:)
                                                          userInfo:nil
                                                           repeats:YES];
    }
    else
    {
        checkSensorTimer = [NSTimer scheduledTimerWithTimeInterval:I2C_SLEEP_INTERVAL
                                                            target:self
                                                          selector:@selector(checkSensor:)
                                                          userInfo:nil
                                                           repeats:YES];
    }

}

- (void)stopCheckSensor
{
    [self sendLedOFF];
    isReact = NO;
    
    [Konashi removeObserver:self];
    if([checkSensorTimer isValid]) [checkSensorTimer invalidate];
    [self resetParameterDisplay];
    //[self hideParameterDisplay];
}

- (void)checkSensor:(NSTimer *)timer
{
    if(isDemo)
    {
        switch(inputSensor)
        {
            case ACCELERATION_SENSOR:
            {
                //Read ACC
                unsigned char data[6];
                [Konashi i2cStartCondition];
                [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
                
                data[0] = 0xA8;   //register address 0x28 + SUB(7) must be equal in order to read multiple bytes.
                [Konashi i2cWrite:1 data:data address:ACCELERATION_SENSOR_ADDRESS];
                
                [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
                [Konashi i2cRestartCondition];
                [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
                [Konashi i2cReadRequest:6 address:ACCELERATION_SENSOR_ADDRESS];
                [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
                break;
            }
                
            case TEMPERATURE_SENSOR:
            {
                //Read Temperature
                unsigned char data[2];
                [Konashi i2cStartCondition];
                [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
                
                data[0]=0x00;
                [Konashi i2cWrite:1 data:data address:TEMPERATURE_SENSOR_ADDRESS];
                [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
                [Konashi i2cRestartCondition];
                [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
                [Konashi i2cReadRequest:2 address:TEMPERATURE_SENSOR_ADDRESS];
                [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
                break;
            }
                
            case ILLUMINANCE_SENSOR:
                [Konashi analogReadRequest:AIO0];
                break;
                
            case PRESSURE_SENSOR:
                [Konashi analogReadRequest:AIO1];
                break;
                
            case VOLUME_SENSOR:
                [Konashi analogReadRequest:AIO2];
                break;
        }
    }
    else
    {
        if(waitI2CResp) return;
        
        switch(checkSensorStep)
        {
            case 0:
                [Konashi i2cStartCondition];
                break;
                
            case 1:
            {
                unsigned char data[1];
                data[0] = 0xA8;   //register address 0x28 + SUB(7) must be equal in order to read multiple bytes.
                [Konashi i2cWrite:1 data:data address:ACCELERATION_SENSOR_ADDRESS];
                break;
            }
            case 2:
                [Konashi i2cRestartCondition];
                break;
                
            case 3:
                waitI2CResp = YES;
                [Konashi i2cReadRequest:6 address:ACCELERATION_SENSOR_ADDRESS];
                break;
                
            case 4:
            {
                //レスポンス待ち
                unsigned char data[6];
                [Konashi i2cRead:6 data:data];
                double ax =  (double)(((signed short) ((unsigned short)data[1]<<8 ^ data[0]))) / 16384.0;
                double ay =  (double)(((signed short) ((unsigned short)data[3]<<8 ^ data[2]))) / 16384.0;
                double az =  (double)(((signed short) ((unsigned short)data[5]<<8 ^ data[4]))) / 16384.0;
                float value = sqrt(ax * ax + ay * ay + az * az);
                
                [self setAccelerationParamX:ax paramY:ay paramZ:az];
                [self checkReaction:value AX:ax AY:ay AZ:az];
                NSLog(@"    ACC_XYZ: %f %f %f", ax, ay, az);
                //NSLog(@"ACC: %f", value);
                //NSLog(@" ");
                
            }
                break;
                
            case 5:
                [Konashi i2cStopCondition];
                break;
        }
        checkSensorStep  = (checkSensorStep + 1) % 6;
    }
}

- (void)updateAio0
{
    float value = [Konashi analogRead:AIO0] / 1000.0;
    [self setIlluminanceParam:value];
    [self checkReaction:value];
    
    NSLog(@"ILM:%.2f", value);
}

- (void)updateAio1
{
    float value = [Konashi analogRead:AIO1] / 1000.0;
    [self setPressureParam:value];
    [self checkReaction:value];
}

- (void)updateAio2
{
    float value = [Konashi analogRead:AIO2] / 1000.0;
    [self setVolumeParam:value];
    [self checkReaction:value];
}

- (void)who_am_i // check Accerelometer
{
    unsigned char data[2];
    
    [Konashi i2cRead:1 data:data];
    [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
    [Konashi i2cStopCondition];
    [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
    [Konashi removeObserver:self];
    [Konashi addObserver:self selector:@selector(updateI2C18) name:KONASHI_EVENT_I2C_READ_COMPLETE];
    NSLog(@"Who am I ? %X", data[0]);
    
    if(data[0] == 0x33)
    {
        [_sensorCondition setBackgroundColor:[UIColor colorWithRed:0.0 green:0.6 blue:0.0 alpha:1.0]];
    }
    else
    {
        [_sensorCondition setBackgroundColor:[UIColor colorWithRed:0.6 green:0.0 blue:0.0 alpha:1.0]];
    }
}

- (void)updateI2C18 // Read Accerelometer
{
    waitI2CResp = NO;
    /*
    unsigned char data[6];
    
    [Konashi i2cRead:6 data:data];
    [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
    [Konashi i2cStopCondition];
    [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
    
    if(isDemo) NSLog(@"ACC:%X,%X,%X,%X,%X,%X", data[0], data[1], data[2], data[3], data[4], data[5]);
    
    double ax =  (double)(((signed short) ((unsigned short)data[1]<<8 ^ data[0]))) / 16384.0;
    double ay =  (double)(((signed short) ((unsigned short)data[3]<<8 ^ data[2]))) / 16384.0;
    double az =  (double)(((signed short) ((unsigned short)data[5]<<8 ^ data[4]))) / 16384.0;

    
    [self setAccelerationParamX:ax paramY:ay paramZ:az];
    float value = sqrt(ax * ax + ay * ay + az * az);
   
    if(isDemo)
    {
        [self checkReaction:value];
    }
    else
    {
        [self checkReaction:value AX:ax AY:ay AZ:az];
    }
    NSLog(@"ACC_XYZ: %f %f %f", ax, ay, az);
    NSLog(@"ACC: %f", value);
    NSLog(@" ");
     */
}

- (void)updateI2C48 // Read Temperature Sensor
{
    unsigned char data[2];
    
    [Konashi i2cRead:2 data:data];
    [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
    [Konashi i2cStopCondition];
    [NSThread sleepForTimeInterval:I2C_SLEEP_INTERVAL];
    
    float value = ((int)data[0] * 256 + (int)data[1]) / 128.0;
    [self setTemperatureParam:value];
    [self checkReaction:value];
    NSLog(@"TEMP:%f", value);

    
}

- (void)checkReaction:(float)value
{
    bool flag;
    switch (condition) {
        case CONDITION_LT:
            flag = (bool)(value < threshold);
            break;
            
        case CONDITION_GT:
            flag = (bool)(value > threshold);
            break;
    }
    
    if(flag && !isReact)
    {
        float r, g, b;
        switch (ledColor)
        {
            case COLOR_RED:    r = 1; g = 0; b= 0; break;
            case COLOR_GREEN:  r = 0; g = 1; b= 0; break;
            case COLOR_BLUE:   r = 0; g = 0; b= 1; break;
            case COLOR_YELLOW: r = 1; g = 1; b= 0; break;
            case COLOR_SKY:    r = 0; g = 1; b= 1; break;
            case COLOR_PURPLE: r = 1; g = 0; b= 1; break;
            case COLOR_WHITE:  r = 1; g = 1; b= 1; break;
        }
        [self sendLedON:10.0 cycle:cycle r:r g:g b:b];
        isReact = YES;
    }
    else if(!flag && isReact)
    {
        [self sendLedOFF];
        isReact = NO;
    }
}

- (void)checkReaction:(float)a AX:(float)ax AY:(float)ay AZ:(float)az
{
    //check shake
    if(isShake)
    {
        NSDate *now = [NSDate date];
        float time = [now timeIntervalSinceDate:actionStartTime];
        if(time > 5.0)
        {
            NSLog(@"Shake LED is END");
            isShake = NO;
            isReact = NO;
            [self sendLedOFF];
            return;
        }
        
    }
    else if(a > 1.6)
    {
        NSLog(@"Shake LED is START");
        isShake = YES;
        isReact = YES;
        actionStartTime = [NSDate date];
        [self sendLedON:0.0 cycle:1.0 r:1.0 g:0.0 b:0.0];
        return;
    }
    
    //check lie on back
    if(az > 0.8 || az < -0.8)
    {
        if (!isReact)
        {
            if(isLieOnBack)
            {
                NSDate *now = [NSDate date];
                float time = [now timeIntervalSinceDate:actionStartTime];
                if(time > 3.0)
                {
                    NSLog(@"Blink LED with Lie on back");
                    [self sendLedON:0.0 cycle:2.0 r:0.0 g:1.0 b:0.0];
                    isReact = YES;
                    return;
                }
            }
            else
            {
                NSLog(@"Lie on back is START");
                isLieOnBack = YES;
                actionStartTime = [NSDate date];
                return;
            }
        }
    }
    else
    {
        if(isReact && isLieOnBack)
        {
            NSLog(@"Lie on back is END");
            isLieOnBack = NO;
            [self sendLedOFF];
            isReact = NO;
            return;
        }
    }
    
    //check lie on side
    if(ay > 0.8 || ay < -0.8)
    {
        if (!isReact)
        {
            if(isLieOnSide)
            {
                NSDate *now = [NSDate date];
                float time = [now timeIntervalSinceDate:actionStartTime];
                if(time > 3.0)
                {
                    NSLog(@"Start blink with Lie on side");
                    [self sendLedON:0.0 cycle:2.0 r:0.0 g:0.0 b:1.0];
                    isReact = YES;
                    return;
                }
            }
            else
            {
                NSLog(@"Lie on side is START");
                isLieOnSide = YES;
                actionStartTime = [NSDate date];
                return;
            }
        }
    }
    else
    {
        if(isReact && isLieOnSide)
        {
            NSLog(@"Lie on side is END");
            isLieOnSide = NO;
            [self sendLedOFF];
            isReact = NO;
            return;
        }
    }
}


#pragma mark - Konashi Output Control

- (void)startBlinkLEDfor:(float)duration by:(float)cycle r:(float)r g:(float)g b:(float)b
{
    [self stopBlinkLED];
    NSLog(@"START BLINK LED : %.1f, %.1f, %.1f", r, g, b);
    
    if(r > 0)
    {
        [Konashi pwmMode:PIO0 mode:KONASHI_PWM_ENABLE_LED_MODE];
        LED_R_ENABLE = YES;
    }
    else
    {
        [Konashi pwmMode:PIO0 mode:KONASHI_PWM_DISABLE];
        LED_R_ENABLE = NO;
    }
    
    if(g > 0)
    {
        [Konashi pwmMode:PIO1 mode:KONASHI_PWM_ENABLE_LED_MODE];
        LED_G_ENABLE = YES;
    }
    else
    {
        [Konashi pwmMode:PIO1 mode:KONASHI_PWM_DISABLE];
        LED_G_ENABLE = NO;
    }
    
    if(b > 0)
    {
        [Konashi pwmMode:PIO2 mode:KONASHI_PWM_ENABLE_LED_MODE];
        LED_B_ENABLE = YES;
    }
    else
    {
        [Konashi pwmMode:PIO2 mode:KONASHI_PWM_DISABLE];
        LED_B_ENABLE = NO;
    }
    
    NSMutableDictionary *blinkInfo = [[NSMutableDictionary alloc] init];
    [blinkInfo setObject:[NSNumber numberWithFloat:duration] forKey:@"duration"];
    [blinkInfo setObject:[NSNumber numberWithFloat:cycle] forKey:@"cycle"];
    [blinkInfo setObject:[NSNumber numberWithFloat:r] forKey:@"r"];
    [blinkInfo setObject:[NSNumber numberWithFloat:g] forKey:@"g"];
    [blinkInfo setObject:[NSNumber numberWithFloat:b] forKey:@"b"];
    [blinkInfo setObject:[NSNumber numberWithFloat:0.0f] forKey:@"time"];
    
    ledTimer = [NSTimer scheduledTimerWithTimeInterval:LED_TIMER_INTERVAL
                                                target:self
                                              selector:@selector(blinkLED:)
                                              userInfo:blinkInfo
                                               repeats:YES];

}

- (void)stopBlinkLED
{
    NSLog(@"STOP BLINK LED");
    if([ledTimer isValid]) [ledTimer invalidate];
    [self offLED];
}

-(void)blinkLED:(NSTimer *)timer
{
    NSMutableDictionary *blinkInfo = [timer userInfo];
    //float duration = [[blinkInfo objectForKey:@"duration"] floatValue];
    float cycle = [[blinkInfo objectForKey:@"cycle"] floatValue];
    float r = [[blinkInfo objectForKey:@"r"] floatValue];
    float g = [[blinkInfo objectForKey:@"g"] floatValue];
    float b = [[blinkInfo objectForKey:@"b"] floatValue];
    float time = [[blinkInfo objectForKey:@"time"] floatValue];
    
    time += LED_TIMER_INTERVAL;
    
    //time limit
    /*
    if(time > duration)
    {
        [self stopBlinkLED];
        return;
    }
     */
    
    float phase = ((int)(time*1000.0) % (int)(cycle*1000.0)) / 1000.0;
    float scale = 1 - cos(phase * M_PI * 2);
    //NSLog(@"BLINKING time:%.3f phase:%.3f scale:%.3f", time, phase, scale);
    [self onLEDwithR:r * scale G:g * scale B:b * scale];
    
    
    [blinkInfo setObject:[NSNumber numberWithFloat:time] forKey:@"time"];
}


- (void)onLEDwithR:(float)r G:(float)g B:(float)b
{
    if([Konashi isConnected])
    {
        if(LED_R_ENABLE) [Konashi pwmLedDrive:PIO0 dutyRatio:(int)(r*100)];
        if(LED_G_ENABLE) [Konashi pwmLedDrive:PIO1 dutyRatio:(int)(g*100)];
        if(LED_B_ENABLE) [Konashi pwmLedDrive:PIO2 dutyRatio:(int)(b*100)];
    }
}

- (void)offLED
{
    if([Konashi isConnected])
    {
        [Konashi pwmMode:PIO0 mode:KONASHI_PWM_DISABLE];
        [Konashi pwmMode:PIO1 mode:KONASHI_PWM_DISABLE];
        [Konashi pwmMode:PIO2 mode:KONASHI_PWM_DISABLE];
    }
}



#pragma mark - Parameter Display

- (void)resetParameterDisplay
{
    [self setAccelerationParamX:0 paramY:0 paramZ:0];
    [self setTemperatureParam:0];
    [self setIlluminanceParam:0];
    [self setPressureParam:0];
    [self setVolumeParam:0];
}


- (void)showParameterDisplay
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    _parameterDisplay.center = CGPointMake(160, 508);
    [UIView commitAnimations];
}

- (void)hideParameterDisplay
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    _parameterDisplay.center = CGPointMake(160, 700);
    [UIView commitAnimations];
}

- (void)setAccelerationParamX:(float)ax paramY:(float)ay paramZ:(float)az
{
    float a = sqrt(ax * ax + ay * ay + az * az);
    _accelerationXBar.progress = [self getBarProgress:ax ofSensor:ACCELERATION_SENSOR];
    _accelerationYBar.progress = [self getBarProgress:ay ofSensor:ACCELERATION_SENSOR];
    _accelerationZBar.progress = [self getBarProgress:az ofSensor:ACCELERATION_SENSOR];
    _accelerationBar.progress = [self getBarProgress:a ofSensor:ACCELERATION_SENSOR];
    _accelerationLabel.text = [NSString stringWithFormat:@"%.2fG", a];
}

- (void)setTemperatureParam:(float)value
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.45];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    _temperatureBar.progress = [self getBarProgress:value ofSensor:TEMPERATURE_SENSOR];
    [UIView commitAnimations];
    _temperatureLabel.text = [NSString stringWithFormat:@"%.1f℃", value];
}

- (void)setIlluminanceParam:(float)value
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.45];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
    _illuminanceBar.progress = [self getBarProgress:value ofSensor:ILLUMINANCE_SENSOR];
    [UIView commitAnimations];
    _illuminanceLabel.text = [NSString stringWithFormat:@"%.2fV", value];
}

- (void)setPressureParam:(float)value
{
    _pressureBar.progress = [self getBarProgress:value ofSensor:PRESSURE_SENSOR];
    _pressureLabel.text = [NSString stringWithFormat:@"%.2fV", value];
}

- (void)setVolumeParam:(float)value
{
    _volumeBar.progress = [self getBarProgress:value ofSensor:VOLUME_SENSOR];
    _volumeLabel.text = [NSString stringWithFormat:@"%.2fV", value];
}

-(float)getBarProgress:(float)value ofSensor:(int)sensor
{
    return (value - [[thresholdMin objectAtIndex:sensor] floatValue]) / ([[thresholdMax objectAtIndex:sensor] floatValue] - [[thresholdMin objectAtIndex:sensor] floatValue]);
}

- (void)setInputSensor:(int)value
{
    //inputSensor = value;
    inputSensor = ACCELERATION_SENSOR;
    
    _accelerationView.hidden = YES;
    _temperatureView.hidden = YES;
    _illuminanceView.hidden = YES;
    _pressureView.hidden = YES;
    _volumeView.hidden = YES;
    
    switch (value)
    {
        case ACCELERATION_SENSOR:
            _accelerationView.hidden = NO;
            break;
            
        case TEMPERATURE_SENSOR:
            _temperatureView.hidden = NO;
            break;
            
        case ILLUMINANCE_SENSOR:
            _illuminanceView.hidden = NO;
            break;
            
        case PRESSURE_SENSOR:
            _pressureView.hidden = NO;
            break;
            
        case VOLUME_SENSOR:
            _volumeView.hidden = NO;
            break;
    }
}

- (void)setLedColor:(int)value
{
    ledColor = value;
}

- (void)setCycle:(float)value
{
    cycle = value;
}

- (void)setThreshold:(float)value
{
    //threshold = value;
    threshold = 1.6;
    float tmin = [[thresholdMin objectAtIndex:inputSensor] floatValue];
    float tmax = [[thresholdMax objectAtIndex:inputSensor] floatValue];
    _thresholdBar.center = CGPointMake(10 + 280 * (threshold - tmin) / (tmax - tmin), _thresholdBar.center.y);
}

- (void)setCondition:(int)value
{
    condition = value;
}







#pragma mark -
#pragma mark - iPhone-iPhone Pairing

- (IBAction)tapIPhonePairing:(id)sender
{
    if(currentSession == nil)
    {
        gkPicker = [[GKPeerPickerController alloc] init];
        gkPicker.delegate = self;
        gkPicker.connectionTypesMask = GKPeerPickerConnectionTypeNearby;
        //picker.connectionTypesMask = GKPeerPickerConnectionTypeNearby | GKPeerPickerConnectionTypeOnline;
        [gkPicker show];
    }
    else
    {
        [currentSession disconnectFromAllPeers];
        currentSession = nil;
        [_iPhonePairingButton setTitle:@"connect" forState:UIControlStateNormal];
        [[_iPhonePairingButton layer] setBackgroundColor:[[UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:1.0] CGColor]];
    }
}

- (void)peerPickerController:(GKPeerPickerController *)picker
     didSelectConnectionType:(GKPeerPickerConnectionType)type
{
}

- (void)peerPickerController:(GKPeerPickerController *)picker
              didConnectPeer:(NSString *)peerID
                   toSession:(GKSession *)session
{
    currentSession = session;
    session.delegate = self;
    [session setDataReceiveHandler:self withContext:nil];
    isReact = NO;
    
    [_iPhonePairingButton setTitle:@"disconnect" forState:UIControlStateNormal];
    [[_iPhonePairingButton layer] setBackgroundColor:[[UIColor colorWithRed:0.0 green:0.6 blue:0.0 alpha:1.0] CGColor]];
    picker.delegate = nil;
    [picker dismiss];
}



#pragma mark - iPhone-iPhone Communication

- (IBAction)touchUpTestButton:(id)sender
{
    [self sendLedOFF];
}

- (IBAction)touchDownTestButton:(id)sender
{
    [self sendLedON:10.0 cycle:1.0 r:1.0 g:0.0 b:0.0];
}

- (void)sendLedON:(float)duration cycle:(float)cycle r:(float)r g:(float)g b:(float)b
{
    if(currentSession)
    {
        NSString* msg = [NSString stringWithFormat:@"ON,%.2f,%.2f,%.2f,%.2f,%.2f", duration, cycle, r, g, b];
        [self sendData:[msg dataUsingEncoding:NSUTF8StringEncoding]];
    }
    else
    {
        //loop back when no-pairing iphone
        [self startBlinkLEDfor:duration by:cycle r:r g:g b:b];
    }
}

- (void)sendLedOFF
{
    if(currentSession)
    {
        NSString* msg = @"OFF";
        [self sendData:[msg dataUsingEncoding:NSUTF8StringEncoding]];
    }
    else
    {
        //loop back when no-pairing iphone
        [self stopBlinkLED];
    }
}

- (void)receiveData:(NSData *)data
           fromPeer:(NSString *)peer
          inSession:(GKSession *)session
            context:(void *)context
{
    NSString* dataString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    NSArray* array = [dataString componentsSeparatedByString:@","];
    
    if ([[array objectAtIndex:0] isEqualToString:@"OFF"])
    {
        [self stopBlinkLED];
    }
    else if ([[array objectAtIndex:0] isEqualToString:@"ON"])
    {
        float duration = [[array objectAtIndex:1] floatValue];
        float cycle    = [[array objectAtIndex:2] floatValue];
        float r        = [[array objectAtIndex:3] floatValue];
        float g        = [[array objectAtIndex:4] floatValue];
        float b        = [[array objectAtIndex:5] floatValue];
        [self startBlinkLEDfor:duration by:cycle r:r g:g b:b];
    }
}

- (void)sendData:(NSData *)data
{
    NSError *error = nil;
    [currentSession sendDataToAllPeers:data
                          withDataMode:GKSendDataReliable
                                 error:&error];
    if (error)
    {
        NSLog(@"%@", [error localizedDescription]);
    }
}



@end
