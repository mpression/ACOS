//
//  HitogataFlipsideViewController.m
//  HitogataApp
//


#import "HitogataFlipsideViewController.h"
#import "HitogataMainViewController.h"

@interface HitogataFlipsideViewController ()

@end

@implementation HitogataFlipsideViewController

int inputSensor;
NSMutableArray *thresholds;
NSMutableArray *cycles;
NSMutableArray *conditions;
NSMutableArray *ledColors;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self loadSetting];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
	_scrollView.contentSize = _childView.bounds.size;
    if(inputSensor < 3)
    {
        _inputChannel1.selectedSegmentIndex = inputSensor;
        _inputChannel2.selectedSegmentIndex = -1;
    }
    else
    {
        _inputChannel1.selectedSegmentIndex = -1;
        _inputChannel2.selectedSegmentIndex = inputSensor - 3;
    }
    
    
    
    [self setSettingForm];
    
}

- (void)setSettingForm
{
    if(inputSensor == NONE_SENSOR)
    {
        _settingForm.alpha = 0.4f;
        _settingForm.userInteractionEnabled = NO;
    }
    else
    {
        _settingForm.alpha = 1.0f;
        _settingForm.userInteractionEnabled = YES;
    }
    
    _thresholdSlider.minimumValue = [[thresholdMin objectAtIndex:inputSensor] floatValue];
    _thresholdSlider.maximumValue = [[thresholdMax objectAtIndex:inputSensor] floatValue];
    _thresholdSlider.value = [[thresholds objectAtIndex:inputSensor] floatValue];
    _thresholdLabel.text = [NSString stringWithFormat:@"%.2f%@", [[thresholds objectAtIndex:inputSensor] floatValue], [thresholdUnits objectAtIndex:inputSensor]];
    
    _cycleSlider.value = [[cycles objectAtIndex:inputSensor] floatValue];
    _cycleLabel.text = [NSString stringWithFormat:@"%.1fs", [[cycles objectAtIndex:inputSensor] floatValue]] ;
    
    _conditionSwitch.selectedSegmentIndex = [[conditions objectAtIndex:inputSensor] intValue];
    
    _ledColor.selectedSegmentIndex = [[ledColors objectAtIndex:inputSensor] intValue];
}

- (void)loadSetting
{
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    
    thresholds = [[ud arrayForKey:@"thresholds"] mutableCopy];
    conditions = [[ud arrayForKey:@"conditions"] mutableCopy];
    cycles     = [[ud arrayForKey:@"cycles"] mutableCopy];
    ledColors  = [[ud arrayForKey:@"ledColors"] mutableCopy];
    
    inputSensor = (int)[ud integerForKey:@"inputSensor"];
}

- (void)saveSetting
{
    if(inputSensor != NONE_SENSOR)
    {
        [thresholds replaceObjectAtIndex:inputSensor withObject:[NSNumber numberWithFloat:_thresholdSlider.value]];
        [conditions replaceObjectAtIndex:inputSensor withObject:[NSNumber numberWithInt:_conditionSwitch.selectedSegmentIndex]];
        [cycles     replaceObjectAtIndex:inputSensor withObject:[NSNumber numberWithFloat:_cycleSlider.value]];
        [ledColors  replaceObjectAtIndex:inputSensor withObject:[NSNumber numberWithInt:_ledColor.selectedSegmentIndex]];
    }
    
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:[thresholds copy] forKey:@"thresholds"];
    [ud setObject:[conditions copy] forKey:@"conditions"];
    [ud setObject:[cycles copy]     forKey:@"cycles"];
    [ud setObject:[ledColors copy]  forKey:@"ledColors"];
    [ud setInteger:inputSensor forKey:@"inputSensor"];
    [ud synchronize];
}



#pragma mark - LED Test

- (IBAction)touchDownTestButton:(id)sender
{
    float r, g, b;
    switch ((int)_testLedColor.selectedSegmentIndex)
    {
        case COLOR_RED:    r = 1; g = 0; b= 0; break;
        case COLOR_GREEN:  r = 0; g = 1; b= 0; break;
        case COLOR_BLUE:   r = 0; g = 0; b= 1; break;
        case COLOR_YELLOW: r = 1; g = 1; b= 0; break;
        case COLOR_SKY:    r = 0; g = 1; b= 1; break;
        case COLOR_PURPLE: r = 1; g = 0; b= 1; break;
        case COLOR_WHITE:  r = 1; g = 1; b= 1; break;
    }
    
    [self.delegate startBlinkLEDfor:10 by:_testCycleSlider.value r:r g:g b:b];
}

- (IBAction)touchUpTestButton:(id)sender
{
    [self.delegate stopBlinkLED];
}

- (IBAction)changeTestCycleSlider:(id)sender
{
    _testCycleLabel.text = [NSString stringWithFormat:@"%.1fs", _testCycleSlider.value] ;
}

- (IBAction)changeTestLedColor:(id)sender {
}




#pragma mark - Actions


- (IBAction)done:(id)sender
{
    [self saveSetting];
    
    [self.delegate setInputSensor:inputSensor];
    [self.delegate setCycle:[[cycles objectAtIndex:inputSensor] floatValue]];
    [self.delegate setLedColor:[[ledColors objectAtIndex:inputSensor] intValue]];
    [self.delegate setThreshold:[[thresholds objectAtIndex:inputSensor] floatValue]];
    [self.delegate setCondition:[[conditions objectAtIndex:inputSensor] floatValue]];
    
    [self.delegate flipsideViewControllerDidFinish:self];
}



- (IBAction)changeInputChannel1:(id)sender
{
    [self saveSetting];
    _inputChannel2.selectedSegmentIndex = -1;
    inputSensor = (int)_inputChannel1.selectedSegmentIndex;
    [self setSettingForm];
}

- (IBAction)changeInputChannel2:(id)sender
{
    [self saveSetting];
    _inputChannel1.selectedSegmentIndex = -1;
    inputSensor = (int)_inputChannel2.selectedSegmentIndex + 3;
    [self setSettingForm];
}

- (IBAction)changeCondition:(id)sender
{
}

- (IBAction)changeLedColor:(id)sender
{
}

- (IBAction)changeThresholdSlider:(id)sender
{
    _thresholdLabel.text = [NSString stringWithFormat:@"%.2f%@", _thresholdSlider.value, [thresholdUnits objectAtIndex:inputSensor]] ;
}

- (IBAction)changeCycleSlider:(id)sender
{
    _cycleLabel.text = [NSString stringWithFormat:@"%.1fs", _cycleSlider.value] ;
}




@end
