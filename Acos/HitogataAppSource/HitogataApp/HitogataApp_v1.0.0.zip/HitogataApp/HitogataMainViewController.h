//
//  HitogataMainViewController.h
//  HitogataApp
//
//

#import <GameKit/GameKit.h>
#import <UIKit/UIKit.h>
#import "HitogataFlipsideViewController.h"

#define LED_TIMER_INTERVAL 0.05f
#define CHECK_SENSOR_INTERVAL 0.5f
#define I2C_SLEEP_INTERVAL 0.1f

#define ACCELERATION_SENSOR_ADDRESS 0x18
#define TEMPERATURE_SENSOR_ADDRESS 0x48


enum {
    NONE_SENSOR          = 0,
    ACCELERATION_SENSOR  = 1,
    TEMPERATURE_SENSOR   = 2,
    ILLUMINANCE_SENSOR   = 3,
    PRESSURE_SENSOR      = 4,
    VOLUME_SENSOR        = 5,
};

enum {
    COLOR_RED     = 0,
    COLOR_GREEN   = 1,
    COLOR_BLUE    = 2,
    COLOR_YELLOW  = 3,
    COLOR_SKY     = 4,
    COLOR_PURPLE  = 5,
    COLOR_WHITE   = 6,
};

enum {
    CONDITION_LT = 0,
    CONDITION_GT = 1,
};

@interface HitogataMainViewController : UIViewController <HitogataFlipsideViewControllerDelegate,GKPeerPickerControllerDelegate,GKSessionDelegate>

@property (weak, nonatomic) IBOutlet UIView *parameterDisplay;
@property (weak, nonatomic) IBOutlet UIButton *devicePairingButton;
@property (weak, nonatomic) IBOutlet UIButton *iPhonePairingButton;
@property (weak, nonatomic) IBOutlet UILabel *sensorCondition;

- (IBAction)tapDevicePairing:(id)sender;
- (IBAction)tapIPhonePairing:(id)sender;


@property (weak, nonatomic) IBOutlet UIButton *settingButton;

@property (weak, nonatomic) IBOutlet UIView *accelerationView;
@property (weak, nonatomic) IBOutlet UIProgressView *accelerationBar;
@property (weak, nonatomic) IBOutlet UIProgressView *accelerationXBar;
@property (weak, nonatomic) IBOutlet UIProgressView *accelerationYBar;
@property (weak, nonatomic) IBOutlet UIProgressView *accelerationZBar;
@property (weak, nonatomic) IBOutlet UILabel *accelerationLabel;

@property (weak, nonatomic) IBOutlet UIView *temperatureView;
@property (weak, nonatomic) IBOutlet UIProgressView *temperatureBar;
@property (weak, nonatomic) IBOutlet UILabel *temperatureLabel;

@property (weak, nonatomic) IBOutlet UIView *illuminanceView;
@property (weak, nonatomic) IBOutlet UIProgressView *illuminanceBar;
@property (weak, nonatomic) IBOutlet UILabel *illuminanceLabel;

@property (weak, nonatomic) IBOutlet UIView *pressureView;
@property (weak, nonatomic) IBOutlet UIProgressView *pressureBar;
@property (weak, nonatomic) IBOutlet UILabel *pressureLabel;

@property (weak, nonatomic) IBOutlet UIView *volumeView;
@property (weak, nonatomic) IBOutlet UIProgressView *volumeBar;
@property (weak, nonatomic) IBOutlet UILabel *volumeLabel;



- (IBAction)touchUpTestButton:(id)sender;
- (IBAction)touchDownTestButton:(id)sender;

@property (weak, nonatomic) IBOutlet UIView *thresholdBar;



- (void)setInputSensor:(int)value;
- (void)setLedColor:(int)value;
- (void)setCycle:(float)value;
- (void)setThreshold:(float)value;

@end
