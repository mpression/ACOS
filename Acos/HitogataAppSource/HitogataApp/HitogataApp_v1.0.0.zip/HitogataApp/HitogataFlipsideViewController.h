//
//  HitogataFlipsideViewController.h
//  HitogataApp
//

#import <UIKit/UIKit.h>

#define thresholdUnits [NSArray arrayWithObjects:@"", @"G", @"℃", @"V", @"V", @"V", nil]
#define thresholdMin [NSArray arrayWithObjects:[NSNumber numberWithFloat:0.0], [NSNumber numberWithFloat:0.0], [NSNumber numberWithFloat:-55.0],[NSNumber numberWithFloat:0.0], [NSNumber numberWithFloat:0.0], [NSNumber numberWithFloat:0.0], nil]
#define thresholdMax [NSArray arrayWithObjects: [NSNumber numberWithFloat:1.0], [NSNumber numberWithFloat:4.0], [NSNumber numberWithFloat:150.0], [NSNumber numberWithFloat:1.33], [NSNumber numberWithFloat:1.33], [NSNumber numberWithFloat:1.33], nil]




@class HitogataFlipsideViewController;

@protocol HitogataFlipsideViewControllerDelegate
- (void)flipsideViewControllerDidFinish:(HitogataFlipsideViewController *)controller;
- (void)startBlinkLEDfor:(float)duration by:(float)cycle r:(float)r g:(float)g b:(float)b;
- (void)stopBlinkLED;
- (void)setInputSensor:(int)value;
- (void)setLedColor:(int)value;
- (void)setCycle:(float)value;
- (void)setThreshold:(float)value;
- (void)setCondition:(int)value;
@end

@interface HitogataFlipsideViewController : UIViewController

@property (weak, nonatomic) id <HitogataFlipsideViewControllerDelegate> delegate;

@property (weak, nonatomic) IBOutlet UISwitch *demoSwitch;

@property (weak, nonatomic) IBOutlet UIView *childView;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UIView *settingForm;

@property (weak, nonatomic) IBOutlet UISegmentedControl *inputChannel1;
@property (weak, nonatomic) IBOutlet UISegmentedControl *inputChannel2;

@property (weak, nonatomic) IBOutlet UISlider *thresholdSlider;
@property (weak, nonatomic) IBOutlet UILabel *thresholdLabel;
@property (weak, nonatomic) IBOutlet UISegmentedControl *conditionSwitch;
@property (weak, nonatomic) IBOutlet UISegmentedControl *ledColor;
@property (weak, nonatomic) IBOutlet UISlider *cycleSlider;
@property (weak, nonatomic) IBOutlet UILabel *cycleLabel;

@property (weak, nonatomic) IBOutlet UISegmentedControl *testLedColor;
@property (weak, nonatomic) IBOutlet UILabel *testCycleLabel;
@property (weak, nonatomic) IBOutlet UISlider *testCycleSlider;

- (IBAction)done:(id)sender;

- (IBAction)changeInputChannel1:(id)sender;
- (IBAction)changeInputChannel2:(id)sender;

- (IBAction)changeThresholdSlider:(id)sender;
- (IBAction)changeCondition:(id)sender;
- (IBAction)changeLedColor:(id)sender;
- (IBAction)changeCycleSlider:(id)sender;

- (IBAction)touchDownTestButton:(id)sender;
- (IBAction)touchUpTestButton:(id)sender;
- (IBAction)changeTestCycleSlider:(id)sender;
- (IBAction)changeTestLedColor:(id)sender;

@end
