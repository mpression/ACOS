//
//  HitogataAppDelegate.h
//  HitogataApp
//

#import <UIKit/UIKit.h>

@interface HitogataAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
