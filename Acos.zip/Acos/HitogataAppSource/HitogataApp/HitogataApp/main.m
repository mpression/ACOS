//
//  main.m
//  HitogataApp
//
//  Created by Naomi Shimada on 2013/10/20.
//  Copyright (c) 2013年 Kousho Shimada. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "HitogataAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([HitogataAppDelegate class]));
    }
}
